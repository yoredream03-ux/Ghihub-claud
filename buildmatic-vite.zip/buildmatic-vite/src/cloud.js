import { supabase } from './lib/supabase.js';

const st = { signedIn: false, known: new Set() };
export const cloud = {
  on: !!supabase,
  get signedIn() { return st.signedIn; },
  onAuth(cb) {
    const { data } = supabase.auth.onAuthStateChange((_e, s) => { st.signedIn = !!s; if (!s) st.known = new Set(); cb(s); });
    return data.subscription;
  },
  async pull() {
    const [p, s] = await Promise.all([
      supabase.from('bm_profiles').select('xp,display_name').maybeSingle(),
      supabase.from('bm_skills').select('id,name,icon,color,progress,code').order('created_at'),
    ]);
    st.known = new Set((s.data || []).map(r => r.id));
    return { xp: p.data ? p.data.xp : null, name: p.data ? p.data.display_name : '', skills: s.data || [] };
  },
  async push(files) {
    const rows = files.map(f => ({ id: f.cid, name: String(f.name).slice(0, 80), icon: String(f.icon || '📄').slice(0, 4),
      color: /^#[0-9a-fA-F]{6}$/.test(f.color) ? f.color : '#64748B', progress: Math.max(0, Math.min(100, +f.progress || 0)), code: String(f.code || '').slice(0, 50000) }));
    const keep = new Set(rows.map(r => r.id));
    const gone = [...st.known].filter(id => !keep.has(id));
    if (rows.length) { const { error } = await supabase.from('bm_skills').upsert(rows); if (error) throw error; }
    if (gone.length) { const { error } = await supabase.from('bm_skills').delete().in('id', gone); if (error) throw error; }
    st.known = keep;
  },
  async award(n, reason) {
    const { data, error } = await supabase.rpc('bm_award_xp', { p_amount: n, p_reason: reason });
    if (error) throw error;
    return data;
  },
};

export function mountAuth() {
  if (!supabase) return;
  const chip = document.createElement('div');
  chip.style.cssText = 'position:fixed;bottom:8px;left:8px;z-index:40;font-size:11px;background:rgba(14,14,18,.85);border:1px solid #232326;border-radius:999px;padding:4px 12px;color:#D4D4D8;cursor:pointer';
  const dlg = document.createElement('dialog');
  dlg.id = 'auth'; dlg.dir = 'rtl';
  dlg.style.cssText = 'max-width:380px;width:92vw;background:#121214;color:#E4E4E7;border:1px solid #232326;border-radius:20px;padding:24px';
  document.body.append(chip, dlg);
  const inp = 'width:100%;margin:6px 0;padding:10px 12px;border-radius:12px;background:#0A0A0B;border:1px solid #2A2A30;color:#fff';
  const btn = 'padding:9px 18px;border-radius:999px;background:#14B8A6;color:#000;font-weight:600;margin-inline-end:8px';
  let mode = 'in';
  const paint = async (msg = '') => {
    const { data } = await supabase.auth.getSession();
    const u = data.session && data.session.user;
    chip.textContent = u ? '● ' + (u.email || '').slice(0, 24) : 'تسجيل الدخول · Sign in';
    dlg.innerHTML = u
      ? `<h2 style="font-weight:700;margin-bottom:8px">حسابك</h2><p style="font-size:13px">${esc(u.email)}</p><p style="font-size:12px;color:#A1A1AA;margin:8px 0">الـskills اللي كتحفظ كتتزامن مع حسابك، والـXP كيتحسب من السيرفر.</p><button id="ao" style="${btn}">خروج</button><button id="ax" style="padding:9px 18px;border-radius:999px;background:#27272A">إغلاق</button>`
      : `<h2 style="font-weight:700;margin-bottom:8px">${mode === 'in' ? 'تسجيل الدخول' : 'إنشاء حساب'}</h2><input id="ae" type="email" autocomplete="email" placeholder="Email" style="${inp}"><input id="ap" type="password" autocomplete="${mode === 'in' ? 'current-password' : 'new-password'}" placeholder="Password (8+)" style="${inp}"><p id="am" style="font-size:12px;color:#FBBF24;min-height:18px">${esc(msg)}</p><button id="ag" style="${btn}">${mode === 'in' ? 'دخول' : 'تسجيل'}</button><button id="as" style="padding:9px 14px;border-radius:999px;background:#27272A">${mode === 'in' ? 'حساب جديد' : 'عندي حساب'}</button>`;
    const q = id => dlg.querySelector('#' + id);
    if (u) { q('ao').onclick = async () => { await supabase.auth.signOut(); paint(); }; q('ax').onclick = () => dlg.close(); return; }
    q('as').onclick = () => { mode = mode === 'in' ? 'up' : 'in'; paint(); };
    q('ag').onclick = async () => {
      const email = q('ae').value.trim(), password = q('ap').value;
      if (!email || password.length < 8) return paint('إيميل صحيح وباسورد 8 حروف على الأقل');
      const r = mode === 'in' ? await supabase.auth.signInWithPassword({ email, password }) : await supabase.auth.signUp({ email, password });
      if (r.error) return paint('خطأ: ' + r.error.message);
      if (mode === 'up' && !r.data.session) return paint('تحقق من إيميلك لتأكيد الحساب ثم سجّل الدخول.');
      dlg.close(); paint();
    };
  };
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  chip.onclick = () => { paint(); dlg.showModal(); };
  supabase.auth.onAuthStateChange(() => paint());
  paint();
}
