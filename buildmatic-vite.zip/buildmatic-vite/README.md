# BUILDMATIC OS (Vite)

## تشغيل محلي
```
npm install
cp .env.example .env
npm run dev
npm run build      # الناتج فـ dist/
```

## النشر على Vercel (الأسهل)
```
npm install && npm run build
npx vercel --prod -b VITE_SUPABASE_URL=https://oqdfhijkrpwtwncerbbk.supabase.co -b VITE_SUPABASE_ANON_KEY=sb_publishable_AzB1MXXhZpWLdTvZtWDg5Q_gGd3t_G9
```
من بعد حط رابط الموقع فـ Supabase > Authentication > URL Configuration (Site URL + Redirect URLs).

## نشر بدائل
- Cloudflare Pages / Netlify / Vercel: Build command `npm run build`، Output `dist`.
- ملف `public/_headers` فيه headers أمان. الـCSP وضعتو **Report-Only**؛ شوف الأخطاء فـ console، وإلا ما كاين شي كسر بدلو لـ `Content-Security-Policy`.

## Supabase
1. أنشئ مشروع، وشغّل `supabase/schema.sql` فـ SQL Editor (الجداول كلها بسمية `bm_`).
2. Authentication: فعّل Email + تأكيد الإيميل (+ Google اختياري)، وفعّل CAPTCHA (Turnstile) فـ Attack Protection.
3. حط `VITE_SUPABASE_URL` و`VITE_SUPABASE_ANON_KEY` فـ `.env` (والمفتاح anon فقط، ما تحطش service_role فالواجهة).
4. الـXP تزيدو غير عبر `supabase.rpc('bm_award_xp', {p_amount, p_reason})`.

## حالة المشروع
- `src/cloud.js` كيدير التسجيل/الدخول وتزامن الـskills (`bm_skills`) والـXP (`bm_award_xp`). الـElite chat والـVault مازال محلي.
- `.env` فيه URL والمفتاح العمومي ديال مشروع skillora.
- Agent كيحتاج دالة سيرفر (Edge Function) فيها مفتاح Anthropic API وكوتا لكل مستخدم؛ ما تحطش المفتاح فالواجهة.
- عوّض `contact@YOUR-DOMAIN` فـ `index.html`.
