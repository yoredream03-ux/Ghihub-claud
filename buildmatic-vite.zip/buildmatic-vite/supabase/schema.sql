-- Run in Supabase SQL editor. All tables use Row-Level Security.
create extension if not exists pgcrypto;

create table public.bm_profiles(
  id uuid primary key references auth.users on delete cascade,
  display_name text check (char_length(display_name) <= 40),
  xp int not null default 0 check (xp >= 0),
  created_at timestamptz not null default now());

create table public.bm_skills(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  name text not null check (char_length(name) <= 80),
  icon text check (char_length(icon) <= 4),
  color text check (color ~ '^#[0-9a-fA-F]{6}$'),
  progress int not null default 0 check (progress between 0 and 100),
  code text not null check (char_length(code) <= 50000),
  created_at timestamptz not null default now());

create table public.bm_vault_items(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  name text not null check (char_length(name) <= 80),
  lang text check (char_length(lang) <= 20),
  code text not null check (char_length(code) <= 50000),
  visibility text not null default 'private' check (visibility in ('private','community')),
  created_at timestamptz not null default now());

create table public.bm_messages(
  id bigint generated always as identity primary key,
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  body text not null check (char_length(body) between 1 and 500),
  reported boolean not null default false,
  created_at timestamptz not null default now());

create table public.bm_xp_events(
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users on delete cascade,
  amount int not null check (amount between 1 and 50),
  reason text,
  created_at timestamptz not null default now());

alter table public.bm_profiles enable row level security;
alter table public.bm_skills enable row level security;
alter table public.bm_vault_items enable row level security;
alter table public.bm_messages enable row level security;
alter table public.bm_xp_events enable row level security;

-- bm_profiles: read all signed-in (names for chat), edit only your display_name (xp is server-only)
create policy profiles_read on public.bm_profiles for select to authenticated using (true);
create policy profiles_update on public.bm_profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
revoke update on public.bm_profiles from authenticated;
grant update (display_name) on public.bm_profiles to authenticated;

create policy skills_own on public.bm_skills for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy vault_read on public.bm_vault_items for select to authenticated using (user_id = auth.uid() or visibility = 'community');
create policy vault_write on public.bm_vault_items for insert to authenticated with check (user_id = auth.uid());
create policy vault_edit on public.bm_vault_items for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy vault_del on public.bm_vault_items for delete to authenticated using (user_id = auth.uid());

-- Elite chat: only users with 3000+ XP (computed server-side)
create policy msg_read on public.bm_messages for select to authenticated
  using ((select xp from public.bm_profiles where id = auth.uid()) >= 3000);
create policy msg_write on public.bm_messages for insert to authenticated
  with check (user_id = auth.uid() and (select xp from public.bm_profiles where id = auth.uid()) >= 3000);
create policy msg_report on public.bm_messages for update to authenticated using (true) with check (true);
revoke update on public.bm_messages from authenticated;
grant update (reported) on public.bm_messages to authenticated;

create policy xp_read on public.bm_xp_events for select to authenticated using (user_id = auth.uid());
-- no insert policy on bm_xp_events: only bm_award_xp() can write.

create function public.bm_handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin insert into public.bm_profiles(id, display_name) values (new.id, left(split_part(new.email,'@',1), 40)); return new; end $$;
create trigger bm_on_auth_user_created after insert on auth.users for each row execute function public.bm_handle_new_user();

create function public.bm_award_xp(p_amount int, p_reason text) returns int language plpgsql security definer set search_path = public as $$
declare today int; total int;
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  if p_amount < 1 or p_amount > 50 then raise exception 'bad amount'; end if;
  select coalesce(sum(amount),0) into today from bm_xp_events where user_id = auth.uid() and created_at >= date_trunc('day', now());
  if today + p_amount > 200 then return (select xp from bm_profiles where id = auth.uid()); end if; -- daily cap
  insert into bm_xp_events(user_id, amount, reason) values (auth.uid(), p_amount, left(p_reason, 60));
  update bm_profiles set xp = xp + p_amount where id = auth.uid() returning xp into total;
  return total;
end $$;
revoke all on function public.bm_award_xp(int, text) from public, anon;
grant execute on function public.bm_award_xp(int, text) to authenticated;

-- chat flood guard: max 5 bm_messages / 10 s per user
create function public.bm_msg_rate() returns trigger language plpgsql as $$
begin
  if (select count(*) from public.bm_messages where user_id = new.user_id and created_at > now() - interval '10 seconds') >= 5
  then raise exception 'rate limit'; end if; return new; end $$;
create trigger msg_rate_t before insert on public.bm_messages for each row execute function public.bm_msg_rate();
